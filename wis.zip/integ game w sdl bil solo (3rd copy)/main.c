#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "menu4.h"
#include "header.h"


// Déclaration des variables
SDL_Surface *screen = NULL;
SDL_Event event;
Menu menu;
int interface = 4; // Interface 4 = menu principal, Interface 5 = choix avatar/input
int done = 1;
int b=0;
int sui=0;
int f=0;
int flechet=0;
int lokhrin=0;
Mix_Chunk *hoverSound = NULL;

int main(int argc, char *argv[]) {
    // Initialisation de SDL
    SDL_Init(SDL_INIT_VIDEO);
    atexit(SDL_Quit);

    Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, 2, 4096);
    hoverSound = Mix_LoadWAV("btt/hover.wav");
    if (!hoverSound) {
        printf("Erreur chargement du son: %s\n", Mix_GetError());
    } 

    // Création de la fenêtre
    screen = SDL_SetVideoMode(1920, 1080, 32, SDL_SWSURFACE);
    if (!screen) {
        printf("Erreur de création de la fenêtre: %s\n", SDL_GetError());
        return 1;
    }

    int lastHovered = -1;
    int hovered ;
    // Initialisation du menu
    initialiserMenu(&menu);

    // Boucle principale
    while (done) {
        // Affichage selon l'interface
        if (interface == 4) {
            afficherMenu4(menu, screen);
        } else if (interface == 5) {
            afficherMenu5(menu, screen);
             if (menu.ButtonValider == 1) {
                moves c;
		movese e;
		haraka a;
		SDL_Surface *screen;

		SDL_Surface* safe_load(const char* filename, int w, int h) {
		    SDL_Surface* loaded = IMG_Load(filename);
		    if (!loaded) {
			loaded = SDL_CreateRGBSurface(SDL_SWSURFACE, w, h, 32, 0,0,0,0);
			SDL_FillRect(loaded, NULL, SDL_MapRGB(loaded->format, 255,0,255));
		    }
		    return loaded;
		}

		
		    int running = 1;
		    
                    
		    srand(time(NULL));

		    // Initialize speeds
		    GameSpeed speed = {
			.characterSpeed = 5,
			.character2Speed = 5
			
		    };

		    // Load assets
		     c.standing = safe_load("character.png", 64, 64);
		    c.sprint1 = safe_load("Run1.png", 64, 64);
		    c.sprint2 = safe_load("Run2.png", 64, 64);
		    c.sprint3 = safe_load("Run3.png", 64, 64);
		    c.sprint4 = safe_load("Run1.png", 64, 64);
		    c.sprint5 = safe_load("Run2.png", 64, 64);
		    c.sprint1_left = safe_load("runl1.png", 64, 64);
		    c.sprint2_left = safe_load("runl2.png", 64, 64);
		    c.sprint3_left = safe_load("runl3.png", 64, 64);
		    c.sprint4_left = safe_load("runl1.png", 64, 64);
		    c.sprint5_left = safe_load("runl2.png", 64, 64);
		    c.attack11 = safe_load("attack1.1.png", 64, 64);
		    c.attack12 = safe_load("attack1.2.png", 64, 64);
		    c.attack13 = safe_load("attack1.3.png", 64, 64);
		    c.attack14 = safe_load("attack1.4.png", 64, 64);
		    c.attack21 = safe_load("Attack_2.1.png", 64, 64);
		    c.attack22 = safe_load("Attack_2.2.png", 64, 64);
		    c.attack23 = safe_load("Attack_2.3.png", 64, 64);
		    c.Dead1 = safe_load("Dead.1.png", 64, 64);
		    c.Dead2 = safe_load("Dead.2.png", 64, 64);
		    c.Dead3 = safe_load("Dead.3.png", 64, 64);
		    a.standinga = safe_load("character.png", 64, 64);
		    a.sprint1a = safe_load("ssprint1.png", 64, 64);
		    a.sprint2a = safe_load("ssprint2.png", 64, 64);
		    a.sprint3a = safe_load("ssprint3.png", 64, 64);
		    a.sprint4a = safe_load("ssprint4.png", 64, 64);
		    a.sprint5a = safe_load("ssprint1.png", 64, 64);
		    a.sprint1_lefta = safe_load("sl1.png", 64, 64);
		    a.sprint2_lefta = safe_load("s2.png", 64, 64);
		    a.sprint3_lefta = safe_load("s3.png", 64, 64);
		    a.sprint4_lefta = safe_load("s4.png", 64, 64);
		    a.sprint5_lefta = safe_load("sl1.png", 64, 64);
		    SDL_Surface *ballImage = safe_load("ball.png", 32, 32);
		    
		    SDL_Surface *background = safe_load("backround.png", 1536, 1024);
		    
		     e.standinge = safe_load("idle.png", 64, 64);
		    e.sprint1e = safe_load("sprint1.png", 64, 64);
		    e.sprint2e = safe_load("sprint2.png", 64, 64);
		    e.sprint3e = safe_load("sprint3.png", 64, 64);
		    e.sprint4e = safe_load("sprint4.png", 64, 64);
		    e.sprint5e = safe_load("sprint1.png", 64, 64);
		    e.sprint1_lefte = safe_load("sprintleft1.png", 64, 64);
		    e.sprint2_lefte = safe_load("sprintl2.png", 64, 64);
		    e.sprint3_lefte = safe_load("sprintl3.png", 64, 64);
		    e.sprint4_lefte = safe_load("sprintl4.png", 64, 64);
		    e.sprint5_lefte = safe_load("sprintleft1.png", 64, 64);
		    e.attack11e = safe_load("att11.png", 64, 64);
		    e.attack12e = safe_load("att12.png", 64, 64);
		    e.attack13e = safe_load("att11.png", 64, 64);
		    e.attack14e = safe_load("att12.png", 64, 64);
		    e.attack21e = safe_load("att3.1.png", 64, 64);
		    e.attack22e = safe_load("att3.2.png", 64, 64);
		    e.dead1 = safe_load("dead3.png", 64, 64);
		    e.dead2 = safe_load("dead2.png", 64, 64);
		    e.dead3 = safe_load("dead3.png", 64, 64);
		    
		    GameAssets assets;
		    initSDL();
		    screen = SDL_SetVideoMode(1536, 1024, 32, SDL_SWSURFACE | SDL_DOUBLEBUF);
		    TTF_Font *font = TTF_OpenFont("arial.ttf", 24);

		    // Initialize game objects
		    Character character = {
			.image = c.standing,
			.position = {400, 1500, 0, 0},
			.velocityY = 0,
			.onGround = 1,
			.moveLeft = 0,
			.moveRight = 0,
			.moveUp = 0,
			.att1 = 0,
			.att2 = 0,
			.Dead = 0,
			.currentFrame = 0,
			.lastFrameTime = 0,
			.health = 100
		    };
		     Character2 character2 = {
			.imagee = e.standinge,
			.positione = {400, 1500, 0, 0},
			.velocityYe = 0,
			.onGrounde = 1,
			.moveLefte = 0,
			.moveRighte = 0,
			.moveUpe = 0,
			.att1e = 0,
			.att2e = 0,
			.dead = 0,
			.currentFramee = 0,
			.lastFrameTime = 0,
			.healthe = 100
		    };
		    
		    character.position.w = character.image->w;
		    character.position.h = character.image->h;
		    character2.positione.w = character2.imagee->w;
		    character2.positione.h = character2.imagee->h;
		    Ball ball = {
			.image = ballImage,
			.position = {0, 0, ballImage->w, ballImage->h},
			.velocityX = 10,
			.active = 0
		    };
		    ball.dpressed=0;
		     Villain villain = {
			.imaga = a.standinga,
			.position = {1200, 650, 0, 0},       
			.alive = 1,
			.moveLeft = 0,
			.moveRight = 0,
			.currentFrame = 0,
			.lastFrameTime = 0,
			.healthen = 1000
		    };

		    GameState gameState = {
			.startTime = SDL_GetTicks(),
			.gameTime = 0,
			.gameOver = 0
		    };

		    int backgroundX = 0;
		    while (running && (character.health > 10)|| (character2.healthe > 10)) {
			gameState.gameTime = (SDL_GetTicks() - gameState.startTime) / 1000;
			
			handleEvents(&sui,&flechet,&lokhrin, &running, &character, &character2, &ball, &speed);
			updateBall(&ball);
			
			updateVillain(&villain,&character , &a ,&character2);
			checkCollision(&ball, &villain, &character ,&character2);
			render(screen, background, &character, &character2, &ball, &villain, 
			      &backgroundX, &gameState, font, &assets);
			
			
			if(sui==1){ 
                                  updateCharacter2(&character2, &e, speed.character2Speed,&sui);
                                  updateCharacter(&character, &c, speed.characterSpeed,&sui);

                         }
                         else{
                                  if(b==1){updateCharacter2(&character2, &e, speed.character2Speed,&sui);}
                                  if(f==1){updateCharacter(&character, &c, speed.characterSpeed,&sui);}
                        }

                        SDL_Delay(16);
		    }

		    // Cleanup
		    SDL_FreeSurface(background);
		    SDL_FreeSurface(ballImage);
		    TTF_CloseFont(font);
		    cleanupSDL();
		    
		 
        }}

        // Gestion des événements
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    done = 0;  // Quitter le jeu
                    break;

                case SDL_MOUSEMOTION:
                    // Gestion de la surbrillance des boutons

                    hovered = -1;
                    if (interface==4){
                       if (event.motion.x >= menu.posButton1.x && event.motion.x <= menu.posButton1.x + menu.button1[0]->w &&
                           event.motion.y >= menu.posButton1.y && event.motion.y <= menu.posButton1.y + menu.button1[0]->h  ) {
                           menu.playSelected1 = 1;
                           sui = 1;
                           hovered = 1;
                       } else {
                           menu.playSelected1 = 0;
                           sui = 0;
                       }
                   
                       if (event.motion.x >= menu.posButton2.x && event.motion.x <= menu.posButton2.x + menu.button2[0]->w &&
                           event.motion.y >= menu.posButton2.y && event.motion.y <= menu.posButton2.y + menu.button2[0]->h) {
                           menu.playSelected2 = 1;
                           sui=0;
                           hovered = 2;
                       } else {
                           menu.playSelected2 = 0;
                           sui=1;
                       }
                    
                       
                   }else if (interface==5){

                    
                        if (event.motion.x >= menu.posButtonValider.x && event.motion.x <= menu.posButtonValider.x + menu.buttonValider[0]->w &&
                            event.motion.y >= menu.posButtonValider.y && event.motion.y <= menu.posButtonValider.y + menu.buttonValider[0]->h) {
                            menu.ButtonValider = 1;
                            hovered = 4;
                        } else {
                            menu.ButtonValider = 0;
                        }
                        if (event.motion.x >= menu.posAvatar1.x && event.motion.x <= menu.posAvatar1.x + menu.avatar1[0]->w &&
                            event.motion.y >= menu.posAvatar1.y && event.motion.y <= menu.posAvatar1.y + menu.avatar1[0]->h) {
                            menu.avatar1Selected = 1;
                            f=1;
                            hovered = 5;
                        } else {
                            menu.avatar1Selected = 0;
                            
                        }

                        if (event.motion.x >= menu.posAvatar2.x && event.motion.x <= menu.posAvatar2.x + menu.avatar2[0]->w &&
                            event.motion.y >= menu.posAvatar2.y && event.motion.y <= menu.posAvatar2.y + menu.avatar2[0]->h) {
                            menu.avatar2Selected = 1;
                            b=1;
                            hovered = 6;
                        } else {
                            menu.avatar2Selected = 0;
                            
                        }

                        if (event.motion.x >= menu.posInput1.x && event.motion.x <= menu.posInput1.x + menu.input1[0]->w &&
                            event.motion.y >= menu.posInput1.y && event.motion.y <= menu.posInput1.y + menu.input1[0]->h) {
                            menu.input1Selected = 1;
                            hovered = 7;
                            flechet = 1;
                        } else {
                            menu.input1Selected = 0;
                        }

                        if (event.motion.x >= menu.posInput2.x && event.motion.x <= menu.posInput2.x + menu.input2[0]->w &&
                            event.motion.y >= menu.posInput2.y && event.motion.y <= menu.posInput2.y + menu.input2[0]->h) {
                            menu.input2Selected = 1;
                            hovered = 8;
                            lokhrin = 1;
                        } else {
                            menu.input2Selected = 0;
                        }
                    }
                    if (event.motion.x >= menu.posButtonBack.x && event.motion.x <= menu.posButtonBack.x + menu.buttonBack[0]->w &&
                           event.motion.y >= menu.posButtonBack.y && event.motion.y <= menu.posButtonBack.y + menu.buttonBack[0]->h) {
                           menu.backSelected = 1;
                           hovered = 3;
                        } else {
                           menu.backSelected = 0;
                      
                        }
                    
                    if (hovered != -1 && hovered != lastHovered) {
                        Mix_PlayChannel(-1, hoverSound, 0);
                    }
                    lastHovered = hovered;

                


                    menu.avatar1Selected = (event.motion.x >= menu.posAvatar1.x && event.motion.x <= menu.posAvatar1.x + menu.avatar1[0]->w &&
                                            event.motion.y >= menu.posAvatar1.y && event.motion.y <= menu.posAvatar1.y + menu.avatar1[0]->h);

                    menu.avatar2Selected = (event.motion.x >= menu.posAvatar2.x && event.motion.x <= menu.posAvatar2.x + menu.avatar2[0]->w &&
                                            event.motion.y >= menu.posAvatar2.y && event.motion.y <= menu.posAvatar2.y + menu.avatar2[0]->h);

                    menu.input1Selected = (event.motion.x >= menu.posInput1.x && event.motion.x <= menu.posInput1.x + menu.input1[0]->w &&
                                           event.motion.y >= menu.posInput1.y && event.motion.y <= menu.posInput1.y + menu.input1[0]->h);

                    menu.input2Selected = (event.motion.x >= menu.posInput2.x && event.motion.x <= menu.posInput2.x + menu.input2[0]->w &&
                                           event.motion.y >= menu.posInput2.y && event.motion.y <= menu.posInput2.y + menu.input2[0]->h);

                   menu.backSelected = (event.motion.x >= menu.posButtonBack.x && event.motion.x <= menu.posButtonBack.x + menu.buttonBack[0]->w &&
                                         event.motion.y >= menu.posButtonBack.y && event.motion.y <= menu.posButtonBack.y + menu.buttonBack[0]->h);
             

       

                     break;
                case SDL_MOUSEBUTTONDOWN:
                    if (event.button.button == SDL_BUTTON_LEFT) {
                        if (interface == 4) {
                            // Vérifier si un bouton du menu principal est cliqué
                            if (event.button.x >= menu.posButton1.x && event.button.x <= menu.posButton1.x + menu.button1[0]->w &&
                                event.button.y >= menu.posButton1.y && event.button.y <= menu.posButton1.y + menu.button1[0]->h) {
                                printf("Bouton 1 cliqué\n");
                                interface = 5;  // Passer à l'interface de sélection d'avatar/input
                            }
                            else if (event.button.x >= menu.posButton2.x && event.button.x <= menu.posButton2.x + menu.button2[0]->w &&
                                     event.button.y >= menu.posButton2.y && event.button.y <= menu.posButton2.y + menu.button2[0]->h) {
                                printf("Bouton 2 cliqué\n");
                                interface = 5;  // Passer à l'interface de sélection d'avatar/input
                            }
                        }
                        else if (interface == 5) {
                            // Vérifier si un bouton avatar/input est cliqué
                            if (event.button.x >= menu.posAvatar1.x && event.button.x <= menu.posAvatar1.x + menu.avatar1[0]->w &&
                                event.button.y >= menu.posAvatar1.y && event.button.y <= menu.posAvatar1.y + menu.avatar1[0]->h) {
                                printf("Avatar 1 sélectionné\n");
                            }
                            else if (event.button.x >= menu.posAvatar2.x && event.button.x <= menu.posAvatar2.x + menu.avatar2[0]->w &&
                                     event.button.y >= menu.posAvatar2.y && event.button.y <= menu.posAvatar2.y + menu.avatar2[0]->h) {
                                printf("Avatar 2 sélectionné\n");
                            }
                            if (event.button.x >= menu.posInput1.x && event.button.x <= menu.posInput1.x + menu.input1[0]->w &&
                                     event.button.y >= menu.posInput1.y && event.button.y <= menu.posInput1.y + menu.input1[0]->h) {
                                printf("Input 1 sélectionné\n");
                            }
                            else if (event.button.x >= menu.posInput2.x && event.button.x <= menu.posInput2.x + menu.input2[0]->w &&
                                     event.button.y >= menu.posInput2.y && event.button.y <= menu.posInput2.y + menu.input2[0]->h) {
                                printf("Input 2 sélectionné\n");
                            }
                            if (event.button.x >= menu.posButtonValider.x && event.button.x <= menu.posButtonValider.x + menu.buttonValider[0]->w &&
                             event.button.y >= menu.posButtonValider.y && event.button.y <= menu.posButtonValider.y + menu.buttonValider[0]->h) {
                             printf("Bouton valider cliqué\n");
                             printf("passer a l interfce suivant\n");
			     interface+=1;
                             
                        }

                        }
    			if (event.button.x >= menu.posButtonBack.x && event.button.x <= menu.posButtonBack.x + menu.buttonBack[0]->w &&
                             event.button.y >= menu.posButtonBack.y && event.button.y <= menu.posButtonBack.y + menu.buttonBack[0]->h) {
                             printf("Bouton Retour cliqué\n");
                             printf("Retour à l'interface precedant\n");
			     interface-=1;
                        }
                    }
                    break;
                case  SDL_KEYDOWN:
                    if (event.key.keysym.sym == SDLK_RETURN && interface == 5) {
                        interface++;
                        printf("Touche Entrée pressée, changement d'interface vers %d\n", interface);
                    }else if (event.key.keysym.sym == SDLK_ESCAPE) {
                        done = 0;
                    }
                    
                    break;

                default:
                    break;
            }
        }
    }

    // Libération des ressources avant de quitter
    libererMenu(&menu);
    Mix_FreeChunk(hoverSound);
    Mix_CloseAudio();
    SDL_Quit();

    return 0;
}
























