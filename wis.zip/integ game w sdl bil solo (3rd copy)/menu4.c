#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "menu4.h"
#include "header.h"
void initialiserMenu(Menu *m) {
    // Charger les images
    m->background = IMG_Load("bkg4.jpg");

    m->button1[0] = IMG_Load("btt/1.png");
    m->button1[1] = IMG_Load("btt/1c.png"); // Bouton sélectionné différent

    m->button2[0] = IMG_Load("btt/2.png");
    m->button2[1] = IMG_Load("btt/2c.png"); // Bouton sélectionné différent

    // Vérification du chargement des images
    if (!m->background || !m->button1[0] || !m->button1[1] || !m->button2[0] || !m->button2[1]) {
        printf("Erreur chargement images : %s\n", IMG_GetError());
        return;
    }

    // Définir les positions
    m->posBackground.x = 0;
    m->posBackground.y = 0;

    m->posButton1.x = 180;
    m->posButton1.y = 600;

    m->posButton2.x = 1200;
    m->posButton2.y = 600;

    m->playSelected1 = 0; // Bouton 1 non sélectionné
    m->playSelected2 = 0; // Bouton 2 non sélectionné

    m->buttonBack[0] = IMG_Load("btt/r.png");
    m->buttonBack[1] = IMG_Load("btt/rc.png");

    m->avatar1[0] = IMG_Load("btt/a.png");
    m->avatar1[1] = IMG_Load("btt/ac.png");

    m->avatar2[0] = IMG_Load("btt/a2.png");
    m->avatar2[1] = IMG_Load("btt/a2c.png");

    m->input1[0] = IMG_Load("btt/i.png");
    m->input1[1] = IMG_Load("btt/ic.png");

    m->input2[0] = IMG_Load("btt/i2.png");
    m->input2[1] = IMG_Load("btt/i2c.png");

    m->av1image = IMG_Load("character.png");
    m->av2image = IMG_Load("idle.png");

    if (!m->buttonBack[0] || !m->buttonBack[1] || !m->avatar1[0] || !m->avatar1[1] ||
        !m->avatar2[0] || !m->avatar2[1] || !m->input1[0] || !m->input1[1] ||
        !m->input2[0] || !m->input2[1]) {
        printf("Erreur chargement images\n");
        return;
    
    }
    m->posAvatar1.x = 150;
    m->posAvatar1.y = 300;

    m->posAvatar2.x = 1245;
    m->posAvatar2.y = 300;

    m->posInput1.x = 150;
    m->posInput1.y = 490;

    m->posInput2.x = 1245;
    m->posInput2.y = 490;

    m->posav1.x = 490;
    m->posav1.y = 320;

    m->posav2.x = 1250;
    m->posav2.y = 320;

    m->posButtonBack.x = 1550;
    m->posButtonBack.y = 870;

    // Initialisation des états des boutons
    m->backSelected = 0;
    m->avatar1Selected = 0;
    m->avatar2Selected = 0;
    m->input1Selected = 0;
    m->input2Selected = 0;

    m->buttonValider[0] = IMG_Load("btt/v.png");
    m->buttonValider[1] = IMG_Load("btt/vc.png");
    if (!m->buttonValider[0] || !m->buttonValider[1] ) {
        printf("Erreur chargement image retour : %s\n", IMG_GetError());
        return;
    }

    // Positionner le bouton valider
    m->posButtonValider.x = 750;
    m->posButtonValider.y = 700;

    m->ButtonValider=0;



}

// Fonction d'affichage du menu principal
void afficherMenu4(Menu m, SDL_Surface *ecran) {
    SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 0, 0, 0)); // Effacer écran avant dessin

    // Affichage du background
    SDL_BlitSurface(m.background, NULL, ecran, &m.posBackground);

    // Affichage des boutons
    SDL_BlitSurface(m.button1[m.playSelected1], NULL, ecran, &m.posButton1);
    SDL_BlitSurface(m.button2[m.playSelected2], NULL, ecran, &m.posButton2);
    
    SDL_BlitSurface(m.buttonBack[m.backSelected], NULL, ecran, &m.posButtonBack);
    
    SDL_Flip(ecran); // Mise à jour de l'affichage
}

// Fonction d'affichage du menu 2 (avatars et inputs)
void afficherMenu5(Menu m, SDL_Surface *ecran) {
    SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 0, 0, 0)); // Effacer écran avant dessin

    // Affichage du background
    SDL_BlitSurface(m.background, NULL, ecran, &m.posBackground);

    // Affichage des avatars et inputs
    SDL_BlitSurface(m.buttonBack[m.backSelected], NULL, ecran, &m.posButtonBack);
    SDL_BlitSurface(m.avatar1[m.avatar1Selected], NULL, ecran, &m.posAvatar1);
    SDL_BlitSurface(m.avatar2[m.avatar2Selected], NULL, ecran, &m.posAvatar2);
    SDL_BlitSurface(m.input1[m.input1Selected], NULL, ecran, &m.posInput1);
    SDL_BlitSurface(m.input2[m.input2Selected], NULL, ecran, &m.posInput2); 
    SDL_BlitSurface(m.av1image, NULL, ecran, &m.posav1);
    SDL_BlitSurface(m.av2image, NULL, ecran, &m.posav2); 



    SDL_BlitSurface(m.buttonValider[m.ButtonValider], NULL, ecran, &m.posButtonValider);

    SDL_Flip(ecran); // Mise à jour de l'affichage

}

// Fonction de libération des ressources
void libererMenu(Menu *m) {
    SDL_FreeSurface(m->background);
    SDL_FreeSurface(m->button1[0]);
    SDL_FreeSurface(m->button1[1]);
    SDL_FreeSurface(m->button2[0]);
    SDL_FreeSurface(m->button2[1]);

    // Libération des avatars et inputs
    SDL_FreeSurface(m->avatar1[0]);
    SDL_FreeSurface(m->avatar2[0]);
    SDL_FreeSurface(m->input1[0]);
    SDL_FreeSurface(m->input2[0]);

    SDL_FreeSurface(m->buttonBack[0]);

    SDL_FreeSurface(m->av1image);
    SDL_FreeSurface(m->av2image);
    SDL_FreeSurface(m->avatar1[1]);
    SDL_FreeSurface(m->avatar2[1]);
    SDL_FreeSurface(m->input1[1]);
    SDL_FreeSurface(m->input2[1]);

    SDL_FreeSurface(m->buttonBack[1]);

    SDL_FreeSurface(m->buttonValider[0]);
    SDL_FreeSurface(m->buttonValider[1]);
}
void initSDL() {
    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();
}

void cleanupSDL() {
    TTF_Quit();
    SDL_Quit();
}

void handleEvents(int *sui,int *flechet,int *lokhrin, int *running, Character *character, Character2 *character2, Ball *ball, GameSpeed *speed) {
    if(*flechet==1){
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
           
                        if (event.type == SDL_QUIT) *running = 0;
			else if (event.type == SDL_KEYDOWN) {
			    switch(event.key.keysym.sym) {
				case SDLK_LEFT: character->moveLeft = 1; break;
				case SDLK_RIGHT: character->moveRight = 1; break;
				case SDLK_s: character->att1 = 1; break;
				case SDLK_d: character->att2 = 1; break;
				case SDLK_UP: character->moveUp = 1; break;
				case SDLK_j: character2->moveLefte = 1; break;
				case SDLK_k: character2->moveRighte = 1; break;
				case SDLK_t: character2->att1e = 1; break;
				case SDLK_y: character2->att2e = 1; break;
				case SDLK_o: character2->moveUpe = 1; break;
				case SDLK_x: 
				    if (!ball->active) {
				        ball->active = 1;
				        ball->position.x = character->position.x + character->position.w;
				        ball->position.y = character->position.y + character->position.h/2;
				    }
			      
			       case SDLK_m: 
				    if (!ball->active) {
				        ball->active = 1;
				        ball->position.x = character2->positione.x + character2->positione.w;
				        ball->position.y = character2->positione.y + character2->positione.h/2;
				    }
				    break;
				case SDLK_PLUS: case SDLK_KP_PLUS:  
				    speed->characterSpeed = (speed->characterSpeed < 25) ? speed->characterSpeed + 2 : 25;
				    speed->character2Speed = (speed->character2Speed < 25) ? speed->character2Speed + 2 : 25; 
				    break;
				case SDLK_MINUS: case SDLK_KP_MINUS: 
				    speed->characterSpeed = (speed->characterSpeed > 1) ? speed->characterSpeed - 1 : 1; 
				    speed->character2Speed = (speed->character2Speed > 1) ? speed->character2Speed - 1 : 1; 
				    break;
				case SDLK_0: case SDLK_KP0: 
				    speed->characterSpeed = 5;
				    speed->character2Speed = 5;
				     
				    break;
			    }
			}
			else if (event.type == SDL_KEYUP) {
			    switch(event.key.keysym.sym) {
				case SDLK_LEFT: character->moveLeft = 0; break;
				case SDLK_RIGHT: character->moveRight = 0; break;
				case SDLK_UP: character->moveUp = 0; break;
				case SDLK_s: character->att1 = 0; break;
				case SDLK_d: character->att2 = 0; break;
				case SDLK_j: character2->moveLefte = 0; break;
				case SDLK_k: character2->moveRighte = 0; break;
				case SDLK_o: character2->moveUpe = 0; break;
				case SDLK_t: character2->att1e = 0; break;
				case SDLK_y: character2->att2e = 0; break;
				

			    }
			}
		    }}

         else if(*lokhrin==1){
                 SDL_Event event;
    	         while (SDL_PollEvent(&event)) {
                        if (event.type == SDL_QUIT) *running = 0;
			else if (event.type == SDL_KEYDOWN) {
			    switch(event.key.keysym.sym) {
				case SDLK_j: character->moveLeft = 1; break;
				case SDLK_k: character->moveRight = 1; break;
				case SDLK_t: character->att1 = 1; break;
				case SDLK_y: character->att2 = 1; break;
				case SDLK_o: character->moveUp = 1; break;
				case SDLK_LEFT: character2->moveLefte = 1; break;
				case SDLK_RIGHT: character2->moveRighte = 1; break;
				case SDLK_s: character2->att1e = 1; break;
				case SDLK_d: character2->att2e = 1; break;
				case SDLK_UP: character2->moveUpe = 1; break;
				case SDLK_m: 
				    if (!ball->active) {
				        ball->active = 1;
				        ball->position.x = character->position.x + character->position.w;
				        ball->position.y = character->position.y + character->position.h/2;
				    }
			      
			       case SDLK_x: 
				    if (!ball->active) {
				        ball->active = 1;
				        ball->position.x = character2->positione.x + character2->positione.w;
				        ball->position.y = character2->positione.y + character2->positione.h/2;
				    }
				    break;
				case SDLK_PLUS: case SDLK_KP_PLUS:  
				    speed->characterSpeed = (speed->characterSpeed < 25) ? speed->characterSpeed + 2 : 25;
				    speed->character2Speed = (speed->character2Speed < 25) ? speed->character2Speed + 2 : 25; 
				    break;
				case SDLK_MINUS: case SDLK_KP_MINUS: 
				    speed->characterSpeed = (speed->characterSpeed > 1) ? speed->characterSpeed - 1 : 1; 
				    speed->character2Speed = (speed->character2Speed > 1) ? speed->character2Speed - 1 : 1; 
				    break;
				case SDLK_0: case SDLK_KP0: 
				    speed->characterSpeed = 5;
				    speed->character2Speed = 5;
				     
				    break;
			    }
			}
			else if (event.type == SDL_KEYUP) {
			    switch(event.key.keysym.sym) {
				case SDLK_j: character->moveLeft = 0; break;
				case SDLK_k: character->moveRight = 0; break;
				case SDLK_t: character->att1 = 0; break;
				case SDLK_y: character->att2 = 0; break;
				case SDLK_o: character->moveUp = 0; break;
				case SDLK_LEFT: character2->moveLefte = 0; break;
				case SDLK_RIGHT: character2->moveRighte = 0; break;
				case SDLK_s: character2->att1e = 0; break;
				case SDLK_d: character2->att2e = 0; break;
				case SDLK_UP: character2->moveUpe = 0; break;;
				

			    }
			}
		    }


}}

void updateCharacter(Character *character, moves *c, int characterSpeed, int *sui) {
  
   if (character->moveLeft) {
        character->position.x -= characterSpeed;
        if (character->position.x < 0) character->position.x = 0;
    }
    if (character->moveRight) {
        character->position.x += characterSpeed;
        if (character->position.x + character->position.w > 1400) {
            character->position.x = 1400 - character->position.w;
        }
    }

    if (character->moveUp && character->onGround) {
        character->velocityY = -35;
        character->onGround = 0;
    }
    character->velocityY += 1;
    character->position.y += character->velocityY;

    Uint32 currentTime = SDL_GetTicks();
    if (currentTime > character->lastFrameTime + 100) {
        character->currentFrame = (character->currentFrame + 1) % 5;
        character->lastFrameTime = currentTime;
    }

    if (character->moveRight) {
        switch(character->currentFrame) {
            case 0: character->image = c->sprint1; break;
            case 1: character->image = c->sprint2; break;
            case 2: character->image = c->sprint3; break;
            case 3: character->image = c->sprint4; break;
            case 4: character->image = c->sprint5; break;
        }
    }
    else if (character->moveLeft) {
        switch(character->currentFrame) {
            case 0: character->image = c->sprint1_left; break;
            case 1: character->image = c->sprint2_left; break;
            case 2: character->image = c->sprint3_left; break;
            case 3: character->image = c->sprint4_left; break;
            case 4: character->image = c->sprint5_left; break;
        }}
        else if (character->att1) {
        switch(character->currentFrame) {
            case 0: character->image = c->attack11; break;
            case 1: character->image = c->attack12; break;
            case 2: character->image = c->attack13; break;
            case 3: character->image = c->attack14; break;
            
        }
    }
        else if (character->att2) {
        switch(character->currentFrame) {
            case 0: character->image = c->attack21; break;
            case 1: character->image = c->attack22; break;
            case 2: character->image = c->attack23; break;
           
            
        }
    }
    else {
        character->image = c->standing;
    }

    if (character->position.y >= 800) {
        character->position.y = 800;
        character->velocityY = 0;
        character->onGround = 1;
    }
   }

void updateBall(Ball *ball) {
    if (ball->active) {
        ball->position.x += ball->velocityX;
        if (ball->position.x > 1536) {
            ball->active = 0;
        }
    }
}

void updateCharacter2(Character2 *character2, movese *e, int character2Speed, int *sui) {
    

    if (character2->moveLefte) {
        character2->positione.x -= character2Speed;
        if (character2->positione.x < 0) character2->positione.x = 0;
    }
    if (character2->moveRighte) {
        character2->positione.x += character2Speed;
        if (character2->positione.x + character2->positione.w > 1536) {
            character2->positione.x = 1536 - character2->positione.w;
        }
    }

    if (character2->moveUpe && character2->onGrounde) {
        character2->velocityYe = -25;
        character2->onGrounde = 0;
    }
    character2->velocityYe += 1;
    character2->positione.y += character2->velocityYe;

    Uint32 currentTime = SDL_GetTicks();
    if (currentTime > character2->lastFrameTime + 100) {
        character2->currentFramee = (character2->currentFramee + 1) % 5;
        character2->lastFrameTime = currentTime;
    }

    if (character2->moveRighte) {
        switch(character2->currentFramee) {
            case 0: character2->imagee = e->sprint1e; break;
            case 1: character2->imagee = e->sprint2e; break;
            case 2: character2->imagee = e->sprint3e; break;
            case 3: character2->imagee = e->sprint4e; break;
            case 4: character2->imagee = e->sprint5e; break;
        }
    }
    else if (character2->moveLefte) {
        switch(character2->currentFramee) {
            case 0: character2->imagee = e->sprint1_lefte; break;
            case 1: character2->imagee = e->sprint2_lefte; break;
            case 2: character2->imagee = e->sprint3_lefte; break;
            case 3: character2->imagee = e->sprint4_lefte; break;
            case 4: character2->imagee = e->sprint5_lefte; break;
        }}
        else if (character2->att1e) {
        switch(character2->currentFramee) {
            case 0: character2->imagee = e->attack11e; break;
            case 1: character2->imagee = e->attack12e; break;
            case 2: character2->imagee = e->attack13e; break;
            case 3: character2->imagee = e->attack14e; break;
            
        }
    }
        else if (character2->att2e) {
        switch(character2->currentFramee) {
            case 0: character2->imagee = e->attack21e; break;
            case 1: character2->imagee = e->attack22e; break;
            
            
        }
    }
    else {
           character2->imagee = e->standinge;
    }

    if (character2->positione.y >= 800) {
        character2->positione.y = 800;
        character2->velocityYe = 0;
        character2->onGrounde = 1;
    }
    
}
void updateVillain(Villain *villain, Character *character , haraka *a ,Character2 *character2 ) {
if(villain->alive) {
    Uint32 currentTime = SDL_GetTicks();
    if (currentTime > villain->lastFrameTime + 100) {
        villain->currentFrame = (villain->currentFrame + 1) % 5;
        villain->lastFrameTime = currentTime;
    }
    if (character->health <= character2->healthe){
	    if (villain->position.x>= character->position.x) {
		villain->position.x -= 3;
		villain->moveLeft = 1;
		
		switch(villain->currentFrame) {
		    case 0: villain->imaga = a->sprint1_lefta; break;
		    case 1: villain->imaga = a->sprint2_lefta; break;
		    case 2: villain->imaga = a->sprint3_lefta; break;
		    case 3: villain->imaga = a->sprint4_lefta; break;
		    case 4: villain->imaga = a->sprint5_lefta; break;
		}
	    }
	    if (villain->position.x<= character->position.x) {
		villain->position.x += 3;
		villain->moveRight = 1;
		switch(villain->currentFrame) {
		    case 0: villain->imaga = a->sprint1a; break;
		    case 1: villain->imaga = a->sprint2a; break;
		    case 2: villain->imaga = a->sprint3a; break;
		    case 3: villain->imaga = a->sprint4a; break;
		    case 4: villain->imaga = a->sprint5a; break;
		}
	    }}

    else{
	    if (villain->position.x>= character2->positione.x) {
		villain->position.x -= 3;
		villain->moveLeft = 1;
		
		switch(villain->currentFrame) {
		    case 0: villain->imaga = a->sprint1_lefta; break;
		    case 1: villain->imaga = a->sprint2_lefta; break;
		    case 2: villain->imaga = a->sprint3_lefta; break;
		    case 3: villain->imaga = a->sprint4_lefta; break;
		    case 4: villain->imaga = a->sprint5_lefta; break;
		}
	    }
	    if (villain->position.x<= character2->positione.x) {
		villain->position.x += 3;
		villain->moveRight = 1;
		switch(villain->currentFrame) {
		    case 0: villain->imaga = a->sprint1a; break;
		    case 1: villain->imaga = a->sprint2a; break;
		    case 2: villain->imaga = a->sprint3a; break;
		    case 3: villain->imaga = a->sprint4a; break;
		    case 4: villain->imaga = a->sprint5a; break;
		}
	    }}

      
   
       
      
}}




void checkCollision(Ball *ball, Villain *villain, Character *character ,Character2 *character2) {
    if (ball->active && villain->alive) {
        if (ball->position.x < villain->position.x + villain->position.w &&
            ball->position.x + ball->position.w > villain->position.x &&
            ball->position.y < villain->position.y + villain->position.h &&
            ball->position.y + ball->position.h > villain->position.y) {
            
            
            ball->active = 0;
            villain->healthen -=10;
       
            character->health += 10;
            if (character->health > 100) character->health = 100;
        }
    }

    if ((villain->alive)||(character->health>10)) {
        if (character->position.x < villain->position.x + villain->position.w &&
            character->position.x + character->position.w > villain->position.x &&
            character->position.y < villain->position.y + villain->position.h &&
            character->position.y + character->position.h > villain->position.y) {
            if((character->att1==1)||(character->att2==1)||(ball->dpressed==1)){
                villain->healthen -=10;
                villain->position.x +=0;}  
            else{villain->alive=1;}
            
            character->health -= 1;
            if (character->position.x < villain->position.x) {
                character->position.x -= 20;
            } else {
                character->position.x += 20;
            }
        }
    }
    if ((villain->alive)||(character2->healthe>10)) {
        if (character2->positione.x < villain->position.x + villain->position.w &&
            character2->positione.x + character2->positione.w > villain->position.x &&
            character2->positione.y < villain->position.y + villain->position.h &&
            character2->positione.y + character2->positione.h > villain->position.y) {
            if((character2->att1e==1)||(character2->att2e==1)||(ball->dpressed==1)){villain->healthen -=10;}
            else{villain->alive=1;}
            
            character2->healthe -= 1;
            if (character2->positione.x < villain->position.x) {
                character2->positione.x -= 20;
            } else {
                character2->positione.x += 20;
            }
        }
    }
    if (villain->healthen<=0){villain->alive=0;}
    
}  


void renderHUD(SDL_Surface *screen, Character *character,Character2 *character2,GameState *gameState, TTF_Font *font ,Villain *villain) {
    SDL_Color white = {255, 255, 255};
    char healthText[32], timeText[32], healtheText[32], healthenText[32];
    
    sprintf(healthText, "Health: %d", character->health);
    sprintf(timeText, "Score: %d", gameState->gameTime);
    sprintf(healtheText, "Healthe: %d", character2->healthe);
    sprintf(healthenText, "healthen: %d", villain->healthen);
    SDL_Surface *healthSurface = TTF_RenderText_Solid(font, healthText, white);
    SDL_Surface *timeSurface = TTF_RenderText_Solid(font, timeText, white);
    SDL_Surface *healtheSurface = TTF_RenderText_Solid(font, healtheText, white);
    SDL_Surface *healthen = TTF_RenderText_Solid(font, healthenText, white);
    SDL_Rect healthPos = {10, 10, 0, 0};
    SDL_Rect timePos = {10, 70, 0, 0};
    SDL_Rect healthePos = {10, 40, 0, 0};
    SDL_Rect healthenPos = {1100, 10, 0, 0};
    SDL_BlitSurface(healthSurface, NULL, screen, &healthPos);
    SDL_BlitSurface(timeSurface, NULL, screen, &timePos);
    SDL_BlitSurface(healtheSurface, NULL, screen, &healthePos);
    SDL_BlitSurface(healthen, NULL, screen, &healthenPos);
    SDL_FreeSurface(healthSurface);
    SDL_FreeSurface(timeSurface);
    SDL_FreeSurface(healtheSurface);
    SDL_FreeSurface(healthen);
}

void render(SDL_Surface *screen, SDL_Surface *background, Character *character,Character2 *character2,  
           Ball *ball,Villain *villain, int *backgroundX, 
           GameState *gameState, TTF_Font *font, GameAssets *assets) {
    // Clear screen
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
    
    
    
    
    SDL_Rect srcRect = { *backgroundX, 0, 1536, 1024 };
    SDL_Rect destRect = { 0, 0, 1536, 1024 };
    SDL_BlitSurface(background, &srcRect, screen, &destRect);
    // Render objects
    if (ball->active) SDL_BlitSurface(ball->image, NULL, screen, &ball->position);
    if (villain->alive) SDL_BlitSurface(villain->imaga, NULL, screen, &villain->position);
    SDL_BlitSurface(character->image, NULL, screen, &character->position);
    SDL_BlitSurface(character2->imagee, NULL, screen, &character2->positione);
    
    // HUD
    renderHUD(screen, character,character2, gameState, font ,villain);
    
    SDL_Flip(screen);
}
























