#ifndef MENU4_H
#define MENU4_H

#include <SDL/SDL.h>

typedef struct {
    SDL_Surface *background;
    SDL_Rect posBackground;

    SDL_Surface *button1[2]; // Deux images pour le bouton 1 (normal et sélectionné)
    SDL_Rect posButton1;
    int playSelected1; // 0 = bouton normal, 1 = bouton sélectionné

    SDL_Surface *button2[2]; // Deux images pour le bouton 2 (normal et sélectionné)
    SDL_Rect posButton2;
    int playSelected2; // 0 = bouton normal, 1 = bouton sélectionné
    
    SDL_Surface *buttonBack[2]; // Normal et sélectionné
    SDL_Rect posButtonBack;
    int backSelected; // 0 = normal, 1 = sélectionné

    SDL_Surface *avatar1[2];
    SDL_Surface *avatar2[2];
    SDL_Surface *input1[2];
    SDL_Surface *input2[2];
    SDL_Surface *av1image;
    SDL_Surface *av2image;    
    int avatar1Selected;
    int avatar2Selected;
    int input1Selected;
    int input2Selected;
   
    SDL_Rect posAvatar1;
    SDL_Rect posAvatar2;
    SDL_Rect posInput1;
    SDL_Rect posInput2;
    SDL_Rect posav1;
    SDL_Rect posav2;
    
    SDL_Surface *buttonValider[2];
    SDL_Rect posButtonValider;
    int ButtonValider;
} Menu;

void initialiserMenu(Menu *m);
void afficherMenu4(Menu m, SDL_Surface *ecran);
void afficherMenu5(Menu m, SDL_Surface *ecran);
void libererMenu(Menu *m);

#endif






